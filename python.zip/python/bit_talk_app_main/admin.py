# from django.contrib import admin
# from bit_talk_app_main import models
# # from django.contrib.auth import get_user_model
# # User = get_user_model()
# # from django.contrib.auth.models import User


# # class coinsAdmin(admin.ModelAdmin):

# #     list_display = ['id', 'cmc_id', 'symbol', 'name', 'logo', 'active']

#     # def __str__(self):
#     #     return str(self.cmc_id) + " - " + self.symbol


# # admin.site.register(User)
# # admin.site.register(models.Coins, coinsAdmin)
# # admin.site.register(models.Entry)
