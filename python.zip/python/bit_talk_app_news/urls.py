# from django.urls import path
# from bit_talk_app_news import views

# urlpatterns = [
#     # path('NewsAPI/', views.NewsViewSet.as_view()),
#     # path('<str:_id>/', views.NewsDetail.as_view()),
#     path('fetch/btc', views.get_news_btc),
# ]
